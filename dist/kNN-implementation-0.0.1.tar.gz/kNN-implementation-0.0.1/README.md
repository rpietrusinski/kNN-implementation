# kNN
Own implementation of k-nearest neighbors algorithm for classification.
The algorithm has been tested od BreastCancer dataset. Beneath is a plot describing the search of optimum *k* parameter value based on the model's accuracy on train and test sets. 


![plot1](https://github.com/rpietrusinski/kNN-implementation/blob/master/plot1.jpg)


The below plots show true and predicted labels for two first principal components.

![plot1](https://github.com/rpietrusinski/kNN-implementation/blob/master/plot2.jpg)
